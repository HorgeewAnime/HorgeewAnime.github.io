$(document).ready(function() {
    callBackAjaxForm(".ajax-login", 'login', is_capcha_login, {
        is_close_poup: true
    });
    callBackAjaxForm(".ajax-register", 'register', is_capcha, {
        is_close_poup: true
    });
    callBackAjaxForm(".ajax-forget", 'forget', is_capcha, {
        is_close_poup: true
    });
    callBackAjaxForm(".ajax-report", 'report', is_capcha, {
        is_close_poup: true,
        is_reload: true
    });
    callBackAjaxForm(".ajax-requests", 'requests', is_capcha, {
        is_close_poup: true,
        is_reload: true
    });
    var lang_id = getCookie('lang_name');
    loadTitleLang(lang_id);
    new_clock();
    var d = new Date();
    var tz = "GMT" + d.toString().split("GMT")[1].split(" (")[0];
    var visitortimezone = "GMT +" + -d.getTimezoneOffset() / 60;
    var timezone = d.toString().split(" ")[5];
    $('.current-time span').text(timezone.slice(0, timezone.length - 2) + ":" + timezone.slice(-2));
    $('.user .avatar').click(function(e) {
        e.preventDefault();
        elm = $('.user .dropdown-menu');
        if ($(elm).hasClass("show")) {
            $(elm).removeClass('show');
            $(this).next().hide();
        } else {
            $(elm).addClass('show');
            $(this).next().show();
        }
    });
    $('#search-toggler').click(function(e) {
        e.preventDefault();
        $("#h-searchbar").toggle();
    });

    $('#show-h-nav-btn').click(function(e) {
        e.preventDefault();
        if ($(this).hasClass("active")) {
            $(this).removeClass('active')
            $("#h-nav ul.nav-menu").hide();
        } else {
            $(this).addClass('active');
            $("#h-nav ul.nav-menu").show();
        }
    });
    $('#h-nav ul li.have-sub a.submenu').click(function(e) {
        e.preventDefault();
        $('#h-nav ul li.have-sub ul').hide();

        if ($(this).parent().hasClass("active")) {
            $(this).parent().removeClass('active');
        } else {
            $('#h-nav li').removeClass('active');
            $(this).parent().addClass('active');
            $(this).parent().find('ul').show();
        }
    });
    $('#lang-switch span').click(function(e) {
        var id = $(this).attr('data-value');
        setCookie('lang_name', id, 30);
        loadTitleLang(id, 1);
        //var lang = getCookie('lang_name');
        //alert(lang);
    });
    $('#schedule-panel .close').click(function(e) {
        $('#schedule-panel').removeClass('active');
    });
    $('a.schedule-toggler').click(function(e) {
        var timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        var date_curent = (new Date()).toISOString().split('T')[0];
        var d = new Date();
        var date_today = date_curent + ' ' + addZero(d.getHours()) + ':' + addZero(d.getMinutes());
        if ($('#schedule-panel').hasClass("active")) {
            $('#schedule-panel').removeClass('active');
        } else {
            $('#schedule-panel').addClass('active');
            callBackAjaxData('ajax/schedule?dates=' + date_curent + '&zone=' + timezone + '&date_today=' + date_today, function(response) {
                $('.load-schedule').html(response);
            });
        }
    });
    var id = -1;
    var timer, value;
    var elm_form_search = '#form-search';
    var link_search = '/filter'; //$(elm_form_search).attr('action');
    $(elm_form_search + " input[name='keyword']").on('keyup keydown paste focus blur', function(e) {
        var keyword = $(this).val();
        keyword = formatKeywords(keyword);
        $(elm_form_search + ' .search-popup').show();
        if (e.type == 'keyup') {
            clearTimeout(timer);
            if (keyword.trim().length >= 2 && value != keyword) {
                timer = setTimeout(function() {
                    value = keyword;
                    callBackAjaxData(link_search + '?keyword=' + keyword, function(response) {
                        $(elm_form_search + ' .show-data').html(response);
                    });
                }, 1000);
            }
        }
        if (e.type == 'paste') {
            var element = $(e.target);
            setTimeout(function() {
                var keyword = $(element).val();
                keyword = formatKeywords(keyword);
                callBackAjaxData(link_search + '?keyword=' + keyword, function(response) {
                    $(elm_form_search + ' .show-data').html(response);
                });
            }, 1000);
        }
        if (e.type == 'focus') {
            if ($(elm_form_search + ' .show-data').html() !== "") {
                $(elm_form_search + ' .show-data').show();
            }
        }
        if (e.type == 'blur') {
            if ($(elm_form_search).is(":hover") === !0) {} else {
                var keyword = "";
                $(elm_form_search + ' .show-data').hide();
                $(elm_form_search + ' .search-popup').hide();
            }
        }
    });
    $(elm_form_search + " button[type='button']").on('click', function(e) {
        var keyword = $(elm_form_search + " input[name='keyword']").val();
        keyword = formatKeywords(keyword);
        if (keyword.length >= 2) {
            window.location.href = base_url + link_search + "?keyword=" + keyword;
        } else {
            $(elm_form_search + " input[name='keyword']").focus();
        }
    });
    $(elm_form_search + " .s-close").on('click', function(e) {
        $(elm_form_search + " input[name='keyword']").val('').focus();
    });
});

function formatKeywords(keyword) {
    var key = keyword.replace(/\s+/g, "+");
    key = key.replace("&", "%");
    return key;
}

function modalPopup(obj, elm = 'login', capcha = true) {
    $('.modal-poup').addClass('show');
    $('#load-fade-poup').html('<div class="modal-backdrop fade show"></div>');
    $('.modal-content').hide();
    $('.modal-content.' + elm).show();
    if (capcha === true) {
        $('.modal-content .captcha').html('');
        $('.modal-content.' + elm + ' .captcha').load(base_url + 'load-capcha');
    }
    if (elm == 'requests' || elm == 'report') {
        $('.modal-dialog-centered').removeClass('with-image');
        $('.modal-dialog-centered').addClass('with-request');
    } else {
        $('.modal-dialog-centered').addClass('with-image');
        $('.modal-dialog-centered').removeClass('with-request');
    }
}

function modalPopupClose(obj, elm = 'login', capcha = true) {
    $('.modal-poup').removeClass('show');
    $('#load-fade-poup').html('');
    if (capcha === true) {
        //grecaptcha.reset();   
        $('.modal-content .captcha').html('');
    }
    if (elm == '#md-requests' || elm == '#md-report') {
        $('.modal-dialog-centered').removeClass('with-image');
        $('.modal-dialog-centered').addClass('with-request');
    } else {
        $('.modal-dialog-centered').addClass('with-image');
        $('.modal-dialog-centered').removeClass('with-request');
    }
}

function checkForm(elm_form, capcha, elm_success) {
    if (capcha === true) {
        var recaptcha = $(elm_form + " .captcha #g-recaptcha-response").val();
        if (recaptcha === "") {
            event.preventDefault();
            $(elm_success).show().html("Please check the recaptcha");
            return false;
        }
    }
    return true;
}

function ajaxTimeOut(elm) {
    $(elm).css({
        'opacity': '0.5'
    });
    setTimeout(function() {
        $(elm).css({
            'opacity': '1'
        });
    }, 500);
}

function ajaxLoadShow(elm) {
    $(elm).css({
        'opacity': '0.5'
    });
}

function ajaxLoadHide(elm) {
    $(elm).css({
        'opacity': '1'
    });
}

function loadHomeWidget(obj, alias) {
    var elm = '.load-widget';
    if (alias == 'random') {
        $(obj).parent().find('.tab').removeClass('active');
        $(obj).addClass('active');
        ajaxLoadShow(elm);
        setTimeout(function() {
            callBackAjaxData('ajax/widget/' + alias + '?page=1', function(response) {
                ajaxLoadHide(elm);
                $(elm).html(response);
            });
        }, 300);
    } else {
        if (!$(obj).hasClass('active')) {
            $(obj).parent().find('.tab').removeClass('active');
            $(obj).addClass('active');
            ajaxLoadShow(elm);
            callBackAjaxData('ajax/widget/' + alias + '?page=1', function(response) {
                ajaxLoadHide(elm);
                $(elm).html(response);
                if (alias == 'updated-dub') {
                    $('.sub-dub-total.sub').hide();
                }
                if (alias == 'updated-sub') {
                    $('.sub-dub-total.dub').hide();
                }
            });
        }
    }
}

function loadHomeWidgetPage(obj, status = '') {
    if ($('#alias_home').length > 0 && $('#alias_home').val() != '') {
        var alias = $('#alias_home').val();
    } else {
        var alias = 'updated-all';
    }
    if ($('#page_home').length > 0 && $('#page_home').val() != '') {
        var page = $('#page_home').val();
    } else {
        var page = 1;
    }
    if (status == 'prev') {
        page = parseInt(page) - 1;
    } else {
        page = parseInt(page) + 1;
    }
    if (page == 0) page = 1;

    var elm = '.load-widget';
    ajaxLoadShow(elm);
    callBackAjaxData('ajax/widget/' + alias + '?page=' + page, function(response) {
        ajaxLoadHide(elm);
        $(elm).html(response);
        if (alias == 'updated-dub') {
            $('.ep-status.sub').hide();
        }
        if (alias == 'updated-sub') {
            $('.ep-status.dub').hide();
        }
    });
}

function loadTopViews(obj, id) {
    if (id > 0) {
        var elm = '.load-top-view';
        ajaxLoadShow(elm);
        $(obj).parent().find('.tab').removeClass('active');
        if (!$(obj).hasClass('active')) {
            $(obj).addClass('active');
            callBackAjaxData('ajax/top-view?id=' + id, function(response) {
                ajaxLoadHide(elm);
                $(elm).html(response);
            });
        }
    }
}

function callBackAjaxData(url, callback, type = 'GET', dataType = 'html') {
    $.ajax({
        type: type,
        dataType: dataType,
        url: base_url + url,
        success: function(response) {
            callback(response)
        },
        error: function(response) {
            callback(response)
        }
    });
}

function loadCapCha(elm_form) {
    $(elm_form + ' .captcha').load(base_url + 'load-capcha');
}

function callBackAjaxForm(elm_form, url, capcha = true, params = {
    is_close_poup: false
}, type = 'POST', dataType = 'json') {
    $(elm_form).submit(function(e) {
        var elm_load = '.loading';
        var elm_danger = elm_form + ' .alert-danger';
        var elm_success = elm_form + ' .alert-success';
        e.preventDefault();
        var chk = checkForm(elm_form, capcha, elm_danger);
        if (chk) {
            $(elm_load).show();
            $(elm_form + ' [type="submit"]').addClass('disabled');
            $.ajax({
                type: type,
                dataType: dataType,
                url: base_url + url,
                data: $(this).serialize() + "&capcha=" + capcha,
                success: function(data) {
                    var message = '';
                    $.each(data.messages, function() {
                        message += this + '<br>';
                    });
                    if (capcha === true) {
                        var count = 0;
                        $(".g-recaptcha").each(function() {
                            grecaptcha.reset(count);
                            count++;
                        });
                    }
                    $(elm_load).hide();
                    $(elm_form + ' [type="submit"]').removeClass('disabled');
                    if (data.status == 200) {
                        $(elm_danger).hide();
                        $(elm_success).show().html(message);
                        $(elm_form).trigger("reset");
                        setTimeout(function() {
                            $(elm_success).hide();
                            if (typeof params.is_close_poup !== "undefined" && params.is_close_poup && params.is_close_poup === true) {
                                modalPopupClose(this);
                            }
                            if (typeof params.is_reload !== "undefined" && params.is_reload && params.is_reload === true) {

                            } else {
                                if (data.url_redirect != '') {
                                    window.location = data.url_redirect;
                                } else {
                                    if (params.url_redirect != undefined && params.url_redirect != null) {
                                        window.location = params.url_redirect;
                                    } else {
                                        location.reload();
                                    }
                                }
                            }
                        }, 3000);
                    } else {
                        $(elm_success).hide();
                        $(elm_danger).show().html(message);
                    }
                },
                error: function(data) {
                    $(elm_load).hide();
                    $(elm_form + ' [type="submit"]').removeClass('disabled');
                }
            });
        }
    });
}

function loadIframePlayer(obj_player, status = 'jw', id_file = '', link_iframe = '') {
    var id_jw = 'mv_' + id_file;
    var link = '';
    var sub = '';
    if (status === 'jw') {
        var tmp = findArrayUrl(JSON.parse(obj_player), id_file);
        if (tmp.length > 0) {
            link = tmp[0].url;
            sub = tmp[0].sub;
        }
    } else {
        link = link_iframe;
    }
    //alert(link);
    $(".loading.watchs").show();
    //$(".play").hide();

    setTimeout(function() {
        $(".loading.watchs").hide();
        //$(".play").show();
        //$(".load-video iframe").attr('src',link);
        var player = jwplayer("myVideo");

        if (status === 'embed') {
            $(".load-video iframe").css({
                'display': 'block'
            });
            $(".load-video #myVideo").css({
                'display': 'none'
            });
            $(".load-video iframe").attr('src', link);
            player.stop();
        } else {
            if (link != '') {
                $(".load-video iframe").css({
                    'display': 'none'
                });
                $(".load-video #myVideo").css({
                    'display': 'block'
                });
                $(".load-video iframe").attr('src', '');
                player.setup({
                    file: link,
                    autostart: 1,
                    tracks: [{
                        file: sub,
                        kind: "captions",
                        'default': true,
                        label: 'English'
                    }],
                });

                var currentPosition = 0;
                var chkCooie = getCookie(id_jw);
                if (chkCooie != null) {
                    currentPosition = chkCooie;
                }
                //console.log('currentPosition: ' + currentPosition);
                player.once('play', function() {
                    'use strict';
                    if (currentPosition > 0 && Math.abs(player.getDuration() - currentPosition) > 5) {
                        player.seek(currentPosition);
                        //console.log('load seek');
                    }
                    //console.log('play');
                    //setTimeout("rememberPosition(\'+av+\')", 5000); 
                    setTimeout(function() {
                        rememberPosition(player, id_jw);
                    }, 5000);
                })
                /*
                player.on('time',function(event){
                  //console.log(event.position);
                });
                  
                player.on('play',function(event){
                  console.log('play 2');
                  //setTimeout("rememberPosition()", 5000); 
                });
                */
                player.on('complete', function(event) {
                    //console.log('complete');
                    setCookie(id_jw, 0, -1);
                });
            }
        }
    }, 1000);
}

function rememberPosition(player, id_jw = '') {
    //var player = jwplayer(id_name);
    //alert(player);
    if (player.getState() == "idle") {
        setCookie(id_jw, 0, -1);
    } else {
        //console.log('load position:' + player.getPosition());
        if (Math.round(player.getPosition()) < Math.round(player.getDuration())) {
            setCookie(id_jw, Math.round(player.getPosition()), 7);
            setTimeout(function() {
                rememberPosition(player, id_jw);
            }, 5000);
        } else {
            //console.log('stop position');
        }
    }
}

function setCookie(c_name, value, expiredays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toUTCString());
}

function getCookie(key) {
    var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
    return keyValue ? keyValue[2] : null;
}

function loadEP(value) {
    var elm_dropdown = '.limit-h .dropdown-item';
    $(elm_dropdown).removeClass('active');
    $(elm_dropdown + '[data-value="' + value + '"]').addClass('active');
    $('.dropdown-menu').hide();
    $('.dropdown.filter').removeClass('show');
    $(".limit-h .dropdown-item").parent().parent().find('.dropdown-toggle').html(value);
    $(".limit-h").removeClass('show');
    $(".ep-range").removeClass('active');
    $(".ep-range[data-range='" + value + "']").addClass('active');
}

function loadComment(id) {
    setTimeout(() => {
        //$("#comment .tab-content[data-type='comment']").html('loading...');
    }, 1000);
}

function dropdownToggle(obj, cls = 'show') {
    $('.dropdown-menu').hide();
    if ($(obj).parent().hasClass(cls)) {
        $(obj).parent().removeClass(cls);
    } else {
        $('.dropdown').removeClass('show');
        $(obj).parent().addClass(cls);
        $(obj).parent().find('.dropdown-menu').show();
    }
}

function addBookmarkEp(elm, idcontent = 0, load = 'loading', idepisode = 0, idfolder = 0, ep = 1) {
    $(elm).addClass('disabled');
    callBackAjaxData('user/bookmark-episode?idcontent=' + idcontent + '&idepisode=' + idepisode + '&idfolder=' + idfolder + '&ep=' + ep + '&load=' + load, function(response) {
        if (response.idfolder_response > 0) {
            $('.add-lists').html('<i class="mdi mdi-pencil"></i> Edit watch list');
            $('.add-lists-bookmark a').removeClass('active');
            $('.add-lists-bookmark a[data-id=' + response.idfolder_response + ']').addClass('active');
            $('.dropdown-divider').show();
            $('.add-lists-bookmark a[data-id=0]').show();
        } else {
            $('.dropdown-divider').hide();
            $('.add-lists-bookmark a[data-id=0]').hide();
            $('.add-lists-bookmark a').removeClass('active');
            $('.add-lists').html('<i class="mdi mdi-bookmark-plus"></i> Bookmark');
        }
        $(elm).removeClass('disabled');
    }, 'GET', 'json');
}

function addBookmarkUser(obj, idcontent = 0, load = 'loading', idepisode = 0, idfolder = 0, ep = 1) {
    $(obj).addClass('disabled');
    callBackAjaxData('user/bookmark-episode?idcontent=' + idcontent + '&idepisode=' + idepisode + '&idfolder=' + idfolder + '&ep=' + ep + '&load=' + load, function(response) {
        if (response.idfolder_response > 0) {
            $(obj).parent().parent().find('.folder-name').html(response.namefolder_response);
            $(obj).parent().parent().find('.final-remove').removeClass('hides');
        } else {
            $(obj).parent().parent().find('.folder-name').html('Add to list');
            $(obj).parent().parent().find('.final-remove').addClass('hides');
        }
        $(obj).removeClass('disabled');
    }, 'GET', 'json');
}

function findArrayUrl(obj, val) {
    return $.grep(obj, function(item) {
        return item.id == val;
    });
};

function loadTitleLang(id, count = 0) {
    //alert(id);
    if (id == null) {
        id = 'jp';
    }
    //alert(id);
    $('#lang-switch span').removeClass('active');
    $('#lang-switch span[data-value="' + id + '"]').addClass('active');

    if (count == 0) {
        if (id == 'en') {
            $('.d-title').each(function() {
                var title = $(this).attr('data-en');
                //console.log(title);
                if (title != '') {
                    $(this).text(title);
                }
            });
        }
    } else {
        $('.d-title').each(function() {
            if (id == 'en') {
                var title = $(this).attr('data-en');
            } else {
                var title = $(this).attr('data-jp');
            }
            if (title != '') {
                $(this).text(title);
            }
        });
    }
}

function new_clock() {
    clock = new Date()
    hour = clock.getHours()
    minutes = clock.getMinutes()
    seconds = clock.getSeconds()
    print_clock = hour + ":" + minutes + ":" + seconds
    $('.current-time time').html(print_clock);
    setTimeout(new_clock, 1000)
}

function showTime() {
    var time = new Date();
    var hour = time.getHours();
    var min = time.getMinutes();
    var sec = time.getSeconds();
    var am_pm = "AM";

    if (hour > 12) {
        hour -= 12;
        am_pm = "PM";
    }
    if (hour == 0) {
        hour = 12;
        am_pm = "AM";
    }

    hour = hour < 10 ? "0" + hour : hour;
    min = min < 10 ? "0" + min : min;
    sec = sec < 10 ? "0" + sec : sec;

    var currentTime = hour + ":" + min + ":" + sec + " " + am_pm;
    $('.current-time time').html(currentTime);
}

function addZero(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}