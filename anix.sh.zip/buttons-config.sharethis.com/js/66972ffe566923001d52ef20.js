window.__sharethis__.init({
    "ts": 1721272727351,
    "inline-share-buttons": {
        "alignment": "center",
        "background_color": "#B581A3",
        "color": "social",
        "enabled": true,
        "font_size": 12,
        "has_spacing": true,
        "is_ssb": false,
        "labels": "counts",
        "language": "en",
        "min_count": 10,
        "networks": ["facebook", "twitter", "messenger", "whatsapp", "reddit", "telegram"],
        "num_networks": 6,
        "num_ssb_networks": 6,
        "padding": 10,
        "radius": 4,
        "show_total": true,
        "size": 32,
        "size_label": "small",
        "spacing": 8,
        "text_color": "#fff",
        "use_native_counts": true,
        "ts": 1721272727212,
        "updated_at": "2024-07-18T03:18:47.212Z"
    }
});